from flask import (
    Flask,
    abort,
    redirect,
    render_template,
    request,
    send_from_directory,
    url_for,
)

import os
import sqlite3

from confirmation_service import (
    CONFIRMABLE_CATEGORIES,
    apply_confirmed_choices,
    create_confirmation,
    load_confirmation_context,
)
from description_parser import extract_features


# =========================================================
# APPLICATION SETUP
# =========================================================

print("Current Working Directory:", os.getcwd())

app = Flask(__name__)

NONE_ALLOWED_CATEGORIES = {
    "hair",
    "eyebrows",
    "moustaches",
    "beards",
}


# =========================================================
# CONFIRMATION HELPERS
# =========================================================

def _display_review_categories(context):
    """Return only categories that need a witness decision."""
    return [
        category
        for category in context["review_categories"]
        if category["candidates"] or category["explicitly_absent"]
    ]


def _load_confirmation_or_404(confirmation_id):
    try:
        return load_confirmation_context(confirmation_id)
    except (FileNotFoundError, TypeError, ValueError):
        abort(404)


# =========================================================
# HOME
# =========================================================

@app.route("/")
def home():
    return render_template("index.html")


# =========================================================
# LOGIN
# =========================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        investigator_id = request.form.get(
            "investigator_id",
            "",
        ).strip()

        password = request.form.get(
            "password",
            "",
        )

        conn = sqlite3.connect("third_eye.db")
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT *
            FROM investigator
            WHERE investigator_id = ?
            AND password = ?
            """,
            (investigator_id, password),
        )

        user = cursor.fetchone()
        conn.close()

        if user:
            return redirect(url_for("witness"))

        return "Invalid Investigator ID or Password"

    return render_template("login.html")


# =========================================================
# REGISTER
# =========================================================

@app.route("/register")
def register():
    return render_template("register.html")


# =========================================================
# CREATE ACCOUNT
# =========================================================

@app.route("/createaccount")
def createaccount():
    return render_template("createaccount.html")


# =========================================================
# SAVE REGISTRATION
# =========================================================

@app.route("/save_registration", methods=["POST"])
def save_registration():
    investigator_id = request.form.get(
        "investigator_id",
        "",
    ).strip()

    agency = request.form.get(
        "agency",
        "",
    ).strip()

    password = request.form.get(
        "password",
        "",
    )

    if not investigator_id or not agency or not password:
        return "All registration fields are required."

    conn = sqlite3.connect("third_eye.db")
    cursor = conn.cursor()

    try:
        cursor.execute(
            """
            INSERT INTO investigator
            (investigator_id, agency, password)
            VALUES (?, ?, ?)
            """,
            (
                investigator_id,
                agency,
                password,
            ),
        )
        conn.commit()

    except sqlite3.IntegrityError:
        conn.close()
        return "Investigator ID already exists."

    conn.close()
    print("Registration Successful")

    return redirect(url_for("login"))


# =========================================================
# WITNESS
# =========================================================

@app.route("/witness")
def witness():
    return render_template("witness.html")


# =========================================================
# SAVE WITNESS AND CREATE CONFIRMATION
# =========================================================

@app.route("/save_witness", methods=["POST"])
def save_witness():
    print("Step A: save_witness called")

    witness_name = request.form.get(
        "witness_name",
        "",
    ).strip()

    description = request.form.get(
        "description",
        "",
    ).strip()

    if not description:
        return "Suspect description is required.", 400

    conn = sqlite3.connect("third_eye.db")
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO witness
        (witness_name, description)
        VALUES (?, ?)
        """,
        (
            witness_name,
            description,
        ),
    )

    witness_id = cursor.lastrowid
    conn.commit()
    conn.close()

    print("Step B: Data saved to database")

    confirmation_id = f"witness-{witness_id}"

    try:
        create_confirmation(
            description,
            confirmation_id,
            top_k=3,
        )
    except Exception as error:
        import traceback

        print("\nERROR CREATING CONFIRMATION:")
        print(error)
        traceback.print_exc()

        return (
            "<h3>Confirmation preview could not be created</h3>"
            f"<p>{error}</p>",
            500,
        )

    return redirect(
        url_for(
            "confirm_features",
            confirmation_id=confirmation_id,
        )
    )


# =========================================================
# WITNESS COMPONENT CONFIRMATION
# =========================================================

@app.route(
    "/confirm/<confirmation_id>",
    methods=["GET", "POST"],
)
def confirm_features(confirmation_id):
    context = _load_confirmation_or_404(confirmation_id)
    review_categories = _display_review_categories(context)
    error_message = None

    if request.method == "POST":
        choices = {}

        for category in review_categories:
            category_name = category["name"]
            selected_id = request.form.get(category_name)

            if not selected_id:
                error_message = (
                    f"Please choose an option for {category['label']}."
                )
                break

            choices[category_name] = selected_id

        if error_message is None:
            try:
                apply_confirmed_choices(
                    context,
                    choices,
                )
            except (TypeError, ValueError) as error:
                error_message = str(error)
            else:
                return redirect(
                    url_for(
                        "confirmation_result",
                        confirmation_id=confirmation_id,
                    )
                )

    return (
        render_template(
            "confirm_features.html",
            context=context,
            review_categories=review_categories,
            none_allowed=NONE_ALLOWED_CATEGORIES,
            error_message=error_message,
        ),
        400 if error_message else 200,
    )


# =========================================================
# CONFIRMED STRUCTURAL REFERENCE
# =========================================================

@app.route("/confirmation/<confirmation_id>/result")
def confirmation_result(confirmation_id):
    context = _load_confirmation_or_404(confirmation_id)

    confirmed_filename = os.path.join(
        "outputs",
        "confirmations",
        confirmation_id,
        "confirmed_reference.png",
    )
    confirmed_path = os.path.join(
        app.static_folder,
        confirmed_filename,
    )

    if not os.path.isfile(confirmed_path):
        abort(404)

    return render_template(
        "confirmed_result.html",
        context=context,
        confirmed_filename=confirmed_filename.replace(os.sep, "/"),
    )


# =========================================================
# GENERATE FACE (LEGACY AI ROUTE)
# =========================================================

@app.route("/generate", methods=["GET", "POST"])
def generate():
    print("Step C: generate route called")

    if request.method == "POST":
        description = request.form.get(
            "description",
            "",
        ).strip()
    else:
        conn = sqlite3.connect("third_eye.db")
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT description
            FROM witness
            ORDER BY id DESC
            LIMIT 1
            """
        )

        row = cursor.fetchone()
        conn.close()

        if row:
            description = row[0]
        else:
            description = ""

    if not description:
        return "No suspect description was provided."

    print("\nDescription received:")
    print(description)

    try:
        # Lazy import: the diffusion model is not loaded while the
        # witness is reviewing deterministic component candidates.
        from generator import generate_face

        attributes = extract_features(description)

        print("\nExtracted attributes:")
        print(attributes)
        print("ATTRIBUTES SENT TO GENERATOR:")
        print(attributes)

        image_path = generate_face(attributes)

        print("\nGenerated image path:")
        print(image_path)

    except Exception as error:
        import traceback

        print("\nERROR DURING FACE GENERATION:")
        print(error)
        traceback.print_exc()

        return (
            "<h3>Face generation failed</h3>"
            f"<p>{error}</p>"
        )

    return render_template(
        "result.html",
        image=image_path,
    )


# =========================================================
# RESULT
# =========================================================

@app.route("/result")
def result():
    return render_template("result.html")


# =========================================================
# SERVE GENERATED IMAGES
# =========================================================

@app.route("/outputs/<path:filename>")
def generated_image(filename):
    output_folder = os.path.join(
        app.root_path,
        "static",
        "outputs",
    )

    return send_from_directory(
        output_folder,
        filename,
    )


# =========================================================
# RUN APPLICATION
# =========================================================

if __name__ == "__main__":
    app.run(
        debug=True,
        use_reloader=False,
    )
