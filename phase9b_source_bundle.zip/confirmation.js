const confirmationForm = document.getElementById("confirmationForm");
const confirmButton = document.getElementById("confirmButton");

if (confirmationForm && confirmButton) {
    confirmationForm.addEventListener("submit", function () {
        confirmButton.disabled = true;
        confirmButton.innerHTML = "Saving confirmation...";
    });
}
