let recognition;
let isRecording = false;

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const description = document.getElementById("description");

// Check browser support
if ("webkitSpeechRecognition" in window) {

    recognition = new webkitSpeechRecognition();

    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    recognition.onstart = function () {

        isRecording = true;
        startBtn.innerHTML = "🎤 Listening...";
        startBtn.disabled = true;
        stopBtn.disabled = false;
    };

    recognition.onend = function () {

        isRecording = false;
        startBtn.innerHTML = "🎤 Start Voice Input";
        startBtn.disabled = false;
        stopBtn.disabled = true;
    };

    recognition.onresult = function (event) {

        let transcript = "";

        for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
        }

        description.value = transcript;
    };

    recognition.onerror = function (event) {
        alert("Speech Recognition Error: " + event.error);
    };

} else {

    alert("Speech Recognition is not supported in this browser.");
}

// Disable Stop button initially
stopBtn.disabled = true;

// Start Recording
startBtn.addEventListener("click", function () {

    if (recognition) {
        recognition.start();
    }

});

// Stop Recording
stopBtn.addEventListener("click", function () {

    if (recognition && isRecording) {
        recognition.stop();
    }

});

// Validate form before submitting
document.querySelector("form").addEventListener("submit", function (event) {

    let witnessName = document.querySelector('input[name="witness_name"]').value.trim();
    let suspectDescription = description.value.trim();

    if (witnessName === "") {
        alert("Please enter Witness Name.");
        event.preventDefault();
        return;
    }

    if (suspectDescription === "") {
        alert("Please provide the suspect description.");
        event.preventDefault();
        return;
    }

    // Form is valid.
    // Flask will automatically submit it to /save_witness.
});