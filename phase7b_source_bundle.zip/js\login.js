function verifyID() {

let id = document.getElementById("investigatorID").value;

let message = document.getElementById("message");

if(id==""){

message.style.color="red";

message.innerHTML="Please enter Investigator ID.";

return;

}

if(id=="INV-2026-1001"){

message.style.color="#22c55e";

message.innerHTML="✔ Investigator already registered.<br>Please Login.";

}
else{

message.style.color="#facc15";

message.innerHTML="No account found.<br>Please Register.";

}

}