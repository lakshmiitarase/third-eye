document.addEventListener("DOMContentLoaded", () => {
  const aboutBtn = document.getElementById("aboutBtn");
  const aboutModal = document.getElementById("aboutModal");
  const closeAbout = document.getElementById("closeAbout");

  aboutBtn.addEventListener("click", (e) => {
    e.preventDefault();
    aboutModal.classList.add("show");
    aboutModal.setAttribute("aria-hidden", "false");
  });

  closeAbout.addEventListener("click", () => {
    aboutModal.classList.remove("show");
    aboutModal.setAttribute("aria-hidden", "true");
  });

  aboutModal.addEventListener("click", (e) => {
    if (e.target === aboutModal) {
      aboutModal.classList.remove("show");
      aboutModal.setAttribute("aria-hidden", "true");
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      aboutModal.classList.remove("show");
      aboutModal.setAttribute("aria-hidden", "true");
    }
  });
});

// Login validation
function login() {

    let id = document.getElementById("investigatorId").value.trim();
    let password = document.getElementById("password").value.trim();
    let check = document.getElementById("confirmCheck").checked;

    if (id === "") {
        alert("Please enter Investigator ID.");
        return;
    }

    if (password === "") {
        alert("Please enter Password.");
        return;
    }

    if (!check) {
        alert("Please confirm that you are an authorized investigator.");
        return;
    }

    window.location.href = "witness.html";
}