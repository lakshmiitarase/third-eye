function verifyID() {

    const id = document.getElementById("investigatorID").value.trim();
    const agency = document.getElementById("agency").value;
    const msg = document.getElementById("message");

    if (id === "" || agency === "") {
        msg.style.color = "red";
        msg.innerHTML = "Please fill all fields.";
        return;
    }

    alert("Verification Successful!");

    window.location.href = "/createaccount";
}