function validatePassword() {

    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;

    let passwordMessage = document.getElementById("passwordMessage");
    let confirmMessage = document.getElementById("confirmMessage");

    passwordMessage.innerHTML = "";
    confirmMessage.innerHTML = "";

    if (password.length < 8) {
        passwordMessage.style.color = "red";
        passwordMessage.innerHTML = "Password must contain at least 8 characters.";
        return false;
    }

    if (password !== confirmPassword) {
        confirmMessage.style.color = "red";
        confirmMessage.innerHTML = "Passwords do not match.";
        return false;
    }

    return true;
}